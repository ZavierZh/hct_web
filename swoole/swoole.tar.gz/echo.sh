#!/bin/bash

echo "test  ...." >&2
cd dsadfasf
